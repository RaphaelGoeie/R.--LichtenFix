Config = {}

Config.WaterPrice = 2 -- this is how much the water costs.

Config.TankModel = -742198632 -- this is the model of the tank if you wan't  to change it.

Config.DrinkingTime = 10000 -- this is specified in ms


Config.ColaPrice = 5 -- this is how much the water costs.

Config.ColaModel = 690372739 -- this is the model of the tank if you wan't  to change it.

Config.DrinkingColaTime = 10000 -- this is specified in msw

Config.StashWeapons = {
    {name = 'WEAPON_GOLFCLUB', label='Golfclub', instash=true},
    {name = 'WEAPON_ASSAULTSMG', label = 'Assault smg', instash=true},
    {name = 'WEAPON_COMBATPDW', label = 'Combat pdw', instash=true},
    {name = 'WEAPON_ASSAULTRIFLE', label = 'Assault rifle', instash=true},
    {name = 'WEAPON_CARBINERIFLE', label = 'Carbine rifle', instash=true},
    {name = 'WEAPON_ADVANCEDRIFLE', label= 'Advanced rifle', instash=true},
    {name = 'WEAPON_SPECIALCARBINE', label= 'Special carbine', instash=true},
    {name = 'WEAPON_BULLPUPRIFLE', label='Bullpup Rifle', instash=true},
    {name = 'WEAPON_COMPACTRIFLE', label= 'Compactrifle', instash=true},
    {name = 'WEAPON_PUMPSHOTGUN', label='Pumpshotgun', instash=true},
    {name = 'WEAPON_BULLPUPSHOTGUN', label='Bullpup shotgun', instash=true},
    {name = 'WEAPON_ASSAULTSHOTGUN', label='Assaut shotgun', instash=true},
    {name = 'WEAPON_HEAVYSHOTGUN', label='Heavy shotgun', instash=true},
    {name = 'WEAPON_SAWNOFFSHOTGUN', label='Sawoff shotgun', instash=true},
    {name = 'WEAPON_MUSKET', label='Musket', instash=true},
    {name = 'WEAPON_DBSHOTGUN', label='DB shotgun', instash=true},
    {name = 'WEAPON_AUTOSHOTGUN', label='Auto shotgun', instash=true},
    {name = 'WEAPON_COMBATMG', label='Combat smg', instash=true},
    {name = 'WEAPON_MG', label='Mg', instash=true},
    {name = 'WEAPON_SMG', label='SMG', instash=true},
    {name = 'WEAPON_GUSENBERG', label='Gunseberg', instash=true}
}



